//
//  ZKAddressPicker.h
//  GoodsManager
//
//  Created by HELLO WORLD on 2019/9/8.
//  Copyright © 2019年 HELLO WORLD. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol ZKAddressPickerDelegate <NSObject>
- (void)addressPickerDidSelectedRow:(NSInteger)row1 row2:(NSInteger)row2 row3:(NSInteger)row3;
@end

@interface ZKAddressPicker : UIView
/// Default is 3, two value to set: 2 or 3,
@property (nonatomic,  assign) NSInteger  columns;
///
@property (nonatomic,  strong) NSArray *dataArray;

@property (nonatomic,    weak) id <ZKAddressPickerDelegate> delegate;

- (void)loadData;
@end

NS_ASSUME_NONNULL_END
