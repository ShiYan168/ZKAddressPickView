//
//  ZKAddressToolBar.h
//  GoodsManager
//
//  Created by HELLO WORLD on 2019/9/8.
//  Copyright © 2019年 HELLO WORLD. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol ZKAddressToolBarDelegate<NSObject>
/// left - 0, right - 1
- (void)toolBarDidClickButton:(NSInteger)leftOrRight;
@end

@interface ZKAddressToolBar : UIView
@property (nonatomic,  strong,  readonly) UIButton *leftButton;
@property (nonatomic,  strong,  readonly) UILabel *titleLable;
@property (nonatomic,  strong,  readonly) UIButton *rightButton;
@property (nonatomic,    weak) id<ZKAddressToolBarDelegate> delegate;
@end

NS_ASSUME_NONNULL_END
